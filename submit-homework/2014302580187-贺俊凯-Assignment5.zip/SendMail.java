package iss.java.mail;

import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

/**
 * @author SilverCrux
 * 
 * ���ڷ����ʼ�
 */
public class SendMail {

	/**
	 * @param recipient 接受者
	 * @param subject 标题
	 * @param content 邮件内容
	 */
	public SendMail(String recipient, String subject, Object content) {
		// TODO Auto-generated constructor stub
		try
		{
			MimeMessage msg = new MimeMessage(Main2014302580187.getSendSession());  
		    msg.setFrom(new InternetAddress(Main2014302580187.getAuthenticator().getUserName())); 
		    msg.setRecipient(RecipientType.TO, new InternetAddress(recipient)); 
		    msg.setSubject(subject);
		    msg.setContent(content.toString(), "text/html;charset=utf-8"); 
		
		    Transport.send(msg);
		    System.out.println("发送成功！");
		}catch(MessagingException e)
		{
			e.printStackTrace();
		}
	}
}
