package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;


/**
 * @author SilverCrux
 *
 */
public class MailAuthenticator extends Authenticator{
	
	private String userName; 
	private String password; 
	
	/**
	 * @param userName 用户名
	 * @param password 用户密码
	 */
	public MailAuthenticator(String userName,String password) {
		// TODO Auto-generated constructor stub
		this.userName = userName;
		this.password = password;
	}
	
	/**
	 * @return 用户名
	 */
	public String getUserName() {
		return userName;
	}
	
	/**
	 * @return 用户密码
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * @param userName 设置用户名
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	/**
	 * @param password 设置用户密码
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/* (non-Javadoc)
	 * @see javax.mail.Authenticator#getPasswordAuthentication()
	 */
	@Override
	protected PasswordAuthentication getPasswordAuthentication() //Override���෽��
	{
		return new PasswordAuthentication(userName, password);
	}
	
	

}
