

/**
 * @author SilverCrux
 * @date 2015.11.16
 */
package iss.java.mail;

import java.io.IOException;
import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;


/**
 * @author SilverCrux
 * @since IMailService
 * 
 */
public class Main2014302580187 implements IMailService{

	private static Session sendSession; 
	private static Session getSession; 
	private static MailAuthenticator authenticator = new MailAuthenticator("silvercrux@sina.com","ISS123456");
	private static Transport transport;  
	private static Store store;
	private static Folder folder; 
	

	/**
	 * @param sendSession 设置发送回话
	 */
	public static void setSendSession(Session sendSession) {
		Main2014302580187.sendSession = sendSession;
	}

	/**
	 * @return 发送会话
	 */
	public static Session getSendSession() {
		return sendSession;
	}

	/**
	 * @param getSession 设置接收会话
	 */
	public static void setGetSession(Session getSession) {
		Main2014302580187.getSession = getSession;
	}
	
	/**
	 * @return 接收会话
	 */
	public static Session getGetSession() {
		return getSession;
	}

 
	/**
	 * @param authenticator 设置登录信息
	 */
	public static void setAuthenticator(MailAuthenticator authenticator) {
		Main2014302580187.authenticator = authenticator;
	}

	/**
	 * @return 登录信息
	 */
	public static MailAuthenticator getAuthenticator() {
		return authenticator;
	}

	/**
	 * @param transport 设置发送端
	 */
	public static void setTransport(Transport transport) {
		Main2014302580187.transport = transport;
	}
	
	/**
	 * @return Transport发送端
	 */
	public static Transport getTransport() {
		return transport;
	}
	
	/**
	 * @param store 存储folder
	 */
	public static void setStore(Store store) {
		Main2014302580187.store = store;
	}
	
	/**
	 * @return Store
	 */
	public static Store getStore() {
		return store;
	}

	/**
	 * @param folder 存储邮件的文件夹
	 */
	public static void setFolder(Folder folder) {
		Main2014302580187.folder = folder;
	}

	/**
	 * @return Folder
	 */
	public static Folder getFolder() {
		return folder;
	}

	/************************IMailService******************************/
	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#connect()
	 */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		new Connect(authenticator);	
	}

	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#send(java.lang.String, java.lang.String, java.lang.Object)
	 */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		new SendMail(recipient, subject, content);  //����sendMail�Ķ������ʼ�
	}

	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#listen()
	 * @return 返回是否有未读邮件
	 */
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		return folder.hasNewMessages(); 
	}

	/* (non-Javadoc)
	 * @see iss.java.mail.IMailService#getReplyMessageContent(java.lang.String, java.lang.String)
	 * @return 返回自动回复邮件内容
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		ReplyMessageContent tmp = new ReplyMessageContent(sender,subject);
		tmp.SelectReplyMessage();
		return null;
	}

	/**
	 * @param args main自带
	 * @throws MessagingException 查询邮件异常
	 * @throws IOException 下载邮件异常
	 */
	public static void main(String args[]) throws MessagingException, IOException
	{
		Main2014302580187 tmp =new Main2014302580187();
		tmp.connect();
		tmp.send("issjava2015@foxmail.com","java��ҵ0","Test");
		System.out.println(tmp.listen());
		tmp.getReplyMessageContent("issjava2015@foxmail.com","自动回复:java作业0");
	}
}
