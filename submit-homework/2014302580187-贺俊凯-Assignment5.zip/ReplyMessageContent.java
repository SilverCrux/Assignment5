package iss.java.mail;



import java.io.IOException;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.search.AndTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;



/**
 * @author SilverCrux
 *
 * �ҵ�������Զ��ظ����ݵ���
 */
public class ReplyMessageContent {

	private String sender;
	private String subject;
	/**
	 * @param sender 邮件来源
	 * @param subject  邮件标题
	 */
	public ReplyMessageContent(String sender,String subject) {
		// TODO Auto-generated constructor stub
			setSender(sender);
			setSubject(subject);	
	}

	/**
	 * @return  来源
	 */
	public String getSender() {
		return sender;
	}

	/**
	 * @param sender 来源
	 */
	public void setSender(String sender) {
		this.sender = sender;
	}

	/**
	 * @return 标题
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject 标题
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @param msg Content-Type为multi的信息
	 * @return 信息内容
	 * @throws IOException 下载邮件错误
	 * @throws MessagingException 查找邮件错误
	 */
	public static String multiMessage(Message msg) throws IOException, MessagingException
	{
		String input = "";
		Multipart mailParts = (Multipart) msg.getContent();
		int i = 0;
		System.out.println(i);
		while (i<mailParts.getCount()) {
			//System.out.println(mailParts.getBodyPart(i).getContentType());
			//System.out.println(mailParts.getBodyPart(i).getContent());
			if(mailParts.getBodyPart(i).getContentType().toString().contains("TEXT/HTML"))
				input += mailParts.getBodyPart(i).getContent().toString();
			i++;
		}
		//String[] inputs = input.split("\n");
		//input = inputs[0];
		String str ="";
		int n = 0;
		while(n<input.length()-1)
			{
			str += input.charAt(n);
			n++;
			}
		System.out.println(input);
		return input;
	}

	/**
	 * @return 返回自动回复的内容
	 */
	public String SelectReplyMessage()
	{
		String input = ""; 
		try {
			SearchTerm search = new AndTerm(new FromStringTerm(sender),new SubjectTerm(subject));	
			Message[] messages = Main2014302580187.getFolder().search(search);	
			for(Message msg: messages)
			{
				if(msg.getContentType().contains("multipart/ALTERNATIVE"))
					{
					multiMessage(msg);
					continue;
					}
				if(msg.getContentType().contains("TEXT"))
				    input += msg.getContent();
				System.out.println(input);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
			return input;
	}	
}
