package iss.java.mail;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;


/**
 * @author SilverCrux
 * 
 */
public class Connect {

	/**
	 * 
	 * @param authenticator 登录信息
	 * 
	 */
	public Connect(Authenticator authenticator) {
		// TODO Auto-generated constructor stub
		try
		{
			
			Properties sendprop = System.getProperties(); 
		    sendprop.put("mail.smtp.auth", "true"); 
		    sendprop.put("mail.smtp.host","smtp.sina.com");
		    Main2014302580187.setSendSession(Session.getInstance(sendprop,authenticator)); 
		    Main2014302580187.setTransport(Main2014302580187.getSendSession().getTransport()); 
		    System.out.println("发送会话连接成功！");
		
		    Properties getprop = System.getProperties();
		    getprop.put("mail.store.protocol","imap");
		    getprop.put("mail.imap.host", "imap.sina.com");
		    Main2014302580187.setGetSession(Session.getInstance(getprop,authenticator));
		    Main2014302580187.setStore(Main2014302580187.getGetSession().getStore());
		    Main2014302580187.getStore().connect();
		    Main2014302580187.setFolder(Main2014302580187.getStore().getFolder("inbox"));
		    Main2014302580187.getFolder().open(Folder.READ_ONLY);
		    System.out.println("接受会话连接成功！");
		}catch(MessagingException e)
		{
			e.printStackTrace();
		}
	}
	
}
